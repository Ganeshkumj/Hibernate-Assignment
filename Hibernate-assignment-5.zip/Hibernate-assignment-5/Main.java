import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateSave {
   public static void main(String[] args) {

    static SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
    Session session = sessionFactory.openSession();
    session.beginTransaction();

    List <Address> addressList = new ArrayList <Address>();

    Address localAddress = new Address();
    localAddress.setStreetName("Walls Street");
    localAddress.setCity("Delhi");
    localAddress.setPinCode("110012");

    addressList.add(localAddress);

    Address permanentAddress = new Address();
    permanentAddress.setStreetName("Murugeshpalya");
    permanentAddress.setCity("Bangalore");
    permanentAddress.setPinCode("560019");

    addressList.add(permanentAddress);

    Employee employee = new Employee();
    employee.setId(1);
    employee.setName("Joe");
    employee.setAddressList(addressList);
    session.save(employee);

    session.save(localAddress);
    session.save(permanentAddress);

    session.getTransaction().commit();

    session.close();
    sessionFactory().close();
  }
}