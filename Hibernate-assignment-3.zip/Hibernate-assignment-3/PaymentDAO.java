package com.onlinetutorialspoint.hibernate.dao;

import com.onlinetutorialspoint.hibernate.model.Card;
import com.onlinetutorialspoint.hibernate.model.Cheque;

public interface PaymentDAO {

    public void saveCard(Card card);

    public void saveCheque(Cheque cheque);
}