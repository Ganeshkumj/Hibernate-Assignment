package com.onlinetutorialspoint.hibernate.model;

public class Card extends Payment {

    private int cardNumber;
    private String cardType;

    public int getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(int cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

}